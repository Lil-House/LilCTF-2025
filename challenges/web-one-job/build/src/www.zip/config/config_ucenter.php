<?php


define('UC_CONNECT', 'mysql');
define('UC_STANDALONE', 0);

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', '123456');
define('UC_DBNAME', 'lilctf');
define('UC_DBCHARSET', 'utf8mb4');
define('UC_DBTABLEPRE', '`lilctf`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_AVTURL', '');
define('UC_AVTPATH', '');

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'N8ear1n0q4s646UeZeod130eLdlbqfs1BbRd447eq866gaUdmek7v2D9r9EeS6vb');
define('UC_API', 'http://192.168.114.134/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>