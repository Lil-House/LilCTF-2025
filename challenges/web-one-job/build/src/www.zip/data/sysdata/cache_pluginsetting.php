<?php
//Discuz! cache file, DO NOT modify me!
//Identify: f9abf1519c37ad28a58e106dc9c7085c

$pluginsetting = array (
);
?>